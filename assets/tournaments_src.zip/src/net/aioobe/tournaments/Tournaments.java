
package net.aioobe.tournaments;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.*;
import java.util.LinkedList;

import javax.swing.*;

public class Tournaments extends JFrame {
    
    // For undo
    LinkedList<String> prevStates = new LinkedList<String>();
    JMenuItem undo;
    JMenu playerInfo = new JMenu("View info");
    
    DblElimTournamentModel model = new DblElimTournamentModel();
    
    private Tournaments() {
        super("Tournaments");
        
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        
        
        // Quick-setup for testing purposes.
//        for (String s : new String[] { "Alpha","Bravo","Charlie","Delta","Echo","Foxtrot","Golf","Hotel" })
//            addPlayer(s);
//        model.regenerateNodes();
        
        createMenu();
        
        setSize(1024, 500);
        add(new DblElimTournamentView(model, this), BorderLayout.CENTER);
        
        setVisible(true);
    }
    
    
    private void createMenu() {
        
        // Tournaments menu
        JMenu tournamentsMenu = new JMenu("Tournaments");
        tournamentsMenu.add(new JMenuItem(new AbstractAction("New Tournament") {
            public void actionPerformed(ActionEvent e) {
                model.clearPlayers();
                repaint();
            }
        }));
        
        tournamentsMenu.add(new JMenuItem(
                new AbstractAction("Save Tournament") {
                    public void actionPerformed(ActionEvent e) {
                        JFileChooser fileChooser = new JFileChooser();
                        fileChooser.showSaveDialog(null);
                        File file = fileChooser.getSelectedFile();
                        if (file != null)
                            try {
                                model.saveState(new FileWriter(file));
                            } catch (Exception ex) {
                            }
                    }
                }));
        
        tournamentsMenu.add(new JMenuItem(
                new AbstractAction("Load Tournament") {
                    public void actionPerformed(ActionEvent e) {
                        JFileChooser fileChooser = new JFileChooser();
                        fileChooser.showOpenDialog(null);
                        File file = fileChooser.getSelectedFile();
                        if (file != null)
                            try {
                                model.loadState(new FileReader(file));
                                regeneratePlayerInfoMenu();
                            } catch (Exception ex) {
                            }
                        repaint();
                    }
                }));
        
        tournamentsMenu.add(undo = new JMenuItem(new AbstractAction("Undo") {
            public void actionPerformed(ActionEvent e) {
                String prevState = prevStates.removeLast();
                model.loadState(new StringReader(prevState));
                regeneratePlayerInfoMenu();
                undo.setEnabled(!prevStates.isEmpty());
                repaint();
            }
        }));
        
        tournamentsMenu.add(new JMenuItem(new AbstractAction("Quit") {
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        }));
        
        // Players menu
        JMenu playersMenu = new JMenu("Players");
        playersMenu.add(new JMenuItem(new AbstractAction("Add Player") {
            public void actionPerformed(ActionEvent e) {
                String playerName = JOptionPane.showInputDialog(null,
                        "Enter name of player", "Add Player",
                        JOptionPane.QUESTION_MESSAGE);
                if (playerName == null)
                    return;
                saveState();
                addPlayer(playerName);
            }
        }));
        
        playersMenu.add(playerInfo);
        
        JMenuBar menuBar = new JMenuBar();
        menuBar.add(tournamentsMenu);
        menuBar.add(playersMenu);
        
        setJMenuBar(menuBar);
        
    }
    
    private void addPlayer(String playerName) {
        Player player = new Player(playerName);
        model.addPlayer(player);
        model.regenerateNodes();
        repaint();
        regeneratePlayerInfoMenu();
    }
    
    private void regeneratePlayerInfoMenu() {
        playerInfo.removeAll();
        for (final Player p : model.players) {
            playerInfo.add(new AbstractAction(p.name) {
                public void actionPerformed(ActionEvent e) {
                    showInfoDialog(p.name);
                }
            });
        }
    }
    
    void saveState() {
        StringWriter w = new StringWriter();
        model.saveState(w);
        prevStates.add(w.getBuffer().toString());
    }
    
    public static void main(String... args) {
        new Tournaments();
    }
    
    private void showInfoDialog(String playerName) {
        File f = new File(playerName+".html");
        String src = "<HTML><H2>Info N/A</H2>The file <CODE>" + playerName +
        		".html</CODE> was not found.<HTML>";
        
        if (f.exists()) {
            try {
                InputStream is = new FileInputStream(f); 
                byte[] bytes = new byte[(int) f.length()];
                int offset = 0, numRead = 0;
                while (offset < bytes.length && (numRead = is.read(bytes, offset, bytes.length - offset)) >= 0)
                    offset += numRead;
                    
                src = new String(bytes);
            } catch (IOException ie) {
            }
        }
        
        JEditorPane editorPane = new JEditorPane("text/html", src);
        editorPane.setEditable(false);
        JDialog dialog = new JDialog(this, "Player info: " + playerName, true);
        dialog.setSize(new Dimension(400, 400));
        dialog.setContentPane(editorPane);
        dialog.setVisible(true);
    }
}
