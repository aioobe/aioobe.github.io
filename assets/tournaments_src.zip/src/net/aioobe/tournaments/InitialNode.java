package net.aioobe.tournaments;

public class InitialNode extends TournamentNode {
    
    Player player;
    
    public InitialNode(Player player) {
	this.player = player;
    }

    public TournamentNode getPred1() {
	return null;
    }

    public TournamentNode getPred2() {
	return null;
    }
    
    public Player getSucceeder() {
	return player;
    }

    public void accept(TournamentVisitor visitor) {
        visitor.visit(this);
    }
    
    public int getRound() {
        return 0;
    }
    
}
