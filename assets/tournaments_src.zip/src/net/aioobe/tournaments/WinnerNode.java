package net.aioobe.tournaments;

public class WinnerNode extends TournamentNode {
    
    TournamentNode pred1, pred2;
    Match match;
    boolean inWb;
    
    WinnerNode(TournamentNode pred1, TournamentNode pred2, boolean inWb) {
        assert pred1 != null && pred2 != null;
        
	match = new Match();
	
        this.inWb = inWb;
	this.pred1 = pred1;
	this.pred2 = pred2;
    }
    
    public Player getSucceeder() {
	switch (match.getStatus()) {
	case P1WON: return pred1.getSucceeder();
	case P2WON: return pred2.getSucceeder();
	default: return null;  // NOT_PLAYED
	}
    }

    public Player getLoser() {
	switch (match.getStatus()) {
	case P1WON: return pred2.getSucceeder();
	case P2WON: return pred1.getSucceeder();
	default: return null;  // NOT_PLAYED
	}
    }
    
    public void accept(TournamentVisitor visitor) {
        visitor.visit(this);
    }
    
    public int getRound() {
        return pred1.getRound() + 1;
    }
}
