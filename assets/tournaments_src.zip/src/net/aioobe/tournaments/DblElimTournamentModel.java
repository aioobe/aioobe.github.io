package net.aioobe.tournaments;

import java.io.*;
import java.util.*;

import net.aioobe.tournaments.Match.Status;

public class DblElimTournamentModel {
    
    TournamentNode final2 = null;
    List<Player> players = new ArrayList<Player>();
    
    public void clearPlayers() {
        players.clear();
        final2 = null;
    }
    
    public void addPlayer(Player p) {
        players.add(p);
    }
    
    public void regenerateNodes() {
        
        if (players.size() < 2)
            return;
        
        List<TournamentNode> wbNodes = new ArrayList<TournamentNode>();
        List<TournamentNode> lbNodes = new ArrayList<TournamentNode>();
        
        // Add initial nodes
        for (Player p : players)
            wbNodes.add(new InitialNode(p));
        
        while (true) {
            if (wbNodes.size() == 1 && lbNodes.size() == 1) { // Final?
                generateFinals(wbNodes.get(0), lbNodes.get(0));
                break;
            } else
                generateNormalRound(wbNodes, lbNodes);
        }
    }
    
    
    private void generateFinals(TournamentNode wbWinNode, TournamentNode lbWinNode) {
	WinnerNode final1win = new WinnerNode(wbWinNode, lbWinNode, true);
	LoserNode final1lose = new LoserNode(final1win);
	final2 = new Final2Node(final1win, final1lose);
    }
    
    public int countLeaves() {
        return countLeaves(getRoot());
    }
    private int countLeaves(TournamentNode root) {
        if (root instanceof InitialNode || root instanceof LoserNode)
            return 1;
        if (root instanceof WinnerNode)
            return countLeaves(((WinnerNode) root).pred1) +
                   countLeaves(((WinnerNode) root).pred2);
        if (root instanceof SingleNode)
            return countLeaves(((SingleNode) root).pred);
        
        assert false;
        return 0;
    }
    
    
    private void generateNormalRound(List<TournamentNode> wns, List<TournamentNode> lns) {
	
        List<TournamentNode> nextWNs = new ArrayList<TournamentNode>();
	List<TournamentNode> nextLNs = new ArrayList<TournamentNode>();
	
	// Generate next rounds winner games
	Iterator<TournamentNode> wnIter = wns.iterator();
	
	if (wns.size() > 1)
	    nextWNs.add(new WinnerNode(wnIter.next(), wnIter.next(), true));
	
	if (wns.size() % 2 == 1)
	    nextWNs.add(new SingleNode(wnIter.next()));
	
	while (wnIter.hasNext())
	    nextWNs.add(new WinnerNode(wnIter.next(), wnIter.next(), true));
	
	// Generate next rounds loser games
	List<TournamentNode> wbLosers = new ArrayList<TournamentNode>();
	for (TournamentNode wn : nextWNs)
	    if (wn instanceof WinnerNode)
		wbLosers.add(new LoserNode((WinnerNode) wn));
	
	List<TournamentNode> lbWinners = new ArrayList<TournamentNode>();
	Iterator<TournamentNode> lgIter = lns.iterator();
	
	if (lns.size() % 2 == 1)
	    lbWinners.add(new SingleNode(lgIter.next()));
	
	while (lgIter.hasNext())
	    lbWinners.add(new WinnerNode(lgIter.next(), lgIter.next(), false));
	
	// Interleave wbLosers with lbWinners
	wnIter = wbLosers.iterator();
	lgIter = lbWinners.iterator();
	while (wnIter.hasNext() || lgIter.hasNext()) {
	    if (wnIter.hasNext()) nextLNs.add(wnIter.next());
	    if (lgIter.hasNext()) nextLNs.add(lgIter.next());
	}
	
	
	// Update round
	wns.clear();
	wns.addAll(nextWNs);
	
	lns.clear();
	lns.addAll(nextLNs);
    }
    
    class MatchIterator implements Iterator<Match>, TournamentVisitor {
        Queue<TournamentNode> q = new LinkedList<TournamentNode>();
        Match next;
        boolean keepSearching;
        public MatchIterator() {
            if (getRoot() != null)
                q.offer(getRoot());
            findNext();
        }
        private void findNext() {
            next = null;
            keepSearching = true;
            while (keepSearching && !q.isEmpty())
                q.remove().accept(this);
        }
        public boolean hasNext() {
            return next != null;
        }
        public Match next() {
            Match toReturn = next;
            findNext();
            return toReturn;
        }
        public void remove() {
            throw new UnsupportedOperationException();
        }
        public void visit(InitialNode initialNode) {
        }
        public void visit(WinnerNode winnerNode) {
            next = winnerNode.match;
            q.offer(winnerNode.pred1);
            q.offer(winnerNode.pred2);
            keepSearching = false;
        }
        public void visit(LoserNode loserNode) {
        }
        public void visit(SingleNode singleNode) {
            q.offer(singleNode.pred);
        }
        public void visit(Final2Node final2Node) {
            visit((WinnerNode) final2Node);
        }
    }
    
    public Iterator<Match> getMatchIterator() {
        return new MatchIterator();
    }
    
    public void saveState(Writer w) {
        PrintWriter pw = new PrintWriter(w);
        pw.println(players.size());
        for (Player p : players)
            pw.println(p.name);
        
        for (Iterator<Match> iter = getMatchIterator(); iter.hasNext();)
            pw.println(iter.next().status);
        
        pw.flush();
        pw.close();
    }
    
    public void loadState(Reader r) {
        clearPlayers();
        Scanner s = new Scanner(r);
        int n = s.nextInt();
        while (n-- > 0)
            addPlayer(new Player(s.next()));
        regenerateNodes();
        for (Iterator<Match> iter = getMatchIterator(); iter.hasNext();)
            iter.next().status = Status.parseStatus(s.next());
    }
    
    TournamentNode getRoot() {
        return final2;
    }
    
}
