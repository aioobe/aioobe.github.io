package net.aioobe.tournaments;

public class SingleNode extends TournamentNode {

    TournamentNode pred;
    
    public SingleNode (TournamentNode pred) {
	this.pred = pred;
    }
    
    public boolean hasLoser() {
	return false;
    }
    
    public Player getSucceeder() {
	return pred.getSucceeder();
    }
    
    public void accept(TournamentVisitor visitor) {
        visitor.visit(this);
    }
    

    public int getRound() {
        return pred.getRound() + 1;
    }
}
