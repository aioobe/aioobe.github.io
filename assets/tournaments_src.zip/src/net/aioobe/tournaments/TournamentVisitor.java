package net.aioobe.tournaments;

interface TournamentVisitor {
    public void visit(InitialNode initialNode);
    public void visit(WinnerNode winnerNode);
    public void visit(LoserNode loserNode);
    public void visit(SingleNode singleNode);
    public void visit(Final2Node final2Node);
}
