package net.aioobe.tournaments;

public class Player {
    String name;
    String htmlFile;
    
    public Player(String name/*, String htmlFile*/) {
        this.name = name;
//        this.htmlFile = htmlFile;
    }
    
    public String toString() {
        return name;
    }
}
