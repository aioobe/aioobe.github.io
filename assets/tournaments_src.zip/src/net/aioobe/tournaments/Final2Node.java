package net.aioobe.tournaments;

import net.aioobe.tournaments.Match.Status;

public class Final2Node extends WinnerNode {
    
    WinnerNode winnerNode;
    
    Final2Node(WinnerNode pred1, TournamentNode pred2) {
        super(pred1, pred2, false);
        this.winnerNode = pred1;
    }
    
    public void accept(TournamentVisitor visitor) {
        visitor.visit(this);
    }
    
    public boolean isNeccessary() {
        return winnerNode.match.status != Status.P1WON;
    }
    
    
}
