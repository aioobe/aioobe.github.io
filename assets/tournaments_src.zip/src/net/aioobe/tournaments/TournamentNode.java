package net.aioobe.tournaments;

public abstract class TournamentNode {
    enum NodeType { WB, LB, FINAL1WIN, FINAL1LOSE, FINAL2 };
    
    public abstract void accept(TournamentVisitor visitor);
    public abstract Player getSucceeder();
    public abstract int getRound();
    
    public boolean isNeccessary() {
        return true;
    }    
}
