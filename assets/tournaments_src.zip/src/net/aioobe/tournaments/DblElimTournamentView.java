package net.aioobe.tournaments;

import java.awt.*;
import java.awt.event.*;
import java.util.*;

import javax.swing.JComponent;

import net.aioobe.tournaments.Match.Status;
import static net.aioobe.tournaments.Match.Status.*;
import static java.awt.Color.*;

public class DblElimTournamentView extends JComponent implements TournamentVisitor {

    DblElimTournamentModel model;
    public final static Color WINCOL = new Color(100, 240, 100);
    public final static Color DEFCOL = WHITE;
    
    // paintComponent temporaries.
    Graphics2D g;
    int top, right, bottom;
    Rectangle rootRect;
    boolean win, faded;
    int roundWidth, leafHeight, boxHeight, boxWidth, headerHeight = 25;
    Map<Rectangle, SetMatchStatus> clickables = new HashMap<Rectangle, SetMatchStatus>();
    
    public DblElimTournamentView(DblElimTournamentModel model, final Tournaments t) {
	this.model = model;
	addMouseListener(new MouseAdapter() {
	    public void mouseClicked(MouseEvent e) {
	        Rectangle hoverRect = getHoverRect(e.getPoint());
	        if (hoverRect == null)
	            return;
	        t.saveState();
	        clickables.get(hoverRect).set();
	        repaint();
	    }
	});
	
	addMouseMotionListener(new MouseMotionAdapter() {
	    public void mouseMoved(MouseEvent e) {
	        Rectangle hoverRect = getHoverRect(e.getPoint());
	        setCursor(hoverRect == null ? new Cursor(Cursor.DEFAULT_CURSOR) : new Cursor(Cursor.HAND_CURSOR));
	    }
	});
    }
    
    public void paintComponent(Graphics g) {
        
        this.g = (Graphics2D) g;
        clickables.clear();
        
        // Clear background
        g.setColor(WHITE);
        g.fillRect(0, 0, getWidth(), getHeight());

        // No tournament generated?
        if (model.final2 == null) {
            drawCenteredString("Add at least two players through the 'Add " +
            		"Player' alternative under the 'Players' menu.",
            		getWidth() / 2, getHeight() / 2);
            return;
        }
        
	int rounds = model.getRoot().getRound() + 1;
	roundWidth = getWidth() / rounds;
	FontMetrics fm = g.getFontMetrics();
	boxHeight = fm.getHeight()+2;
	boxWidth = roundWidth / 2;
	
	// -1 because final1lose occupies no extra space
	int leavesToFit = model.countLeaves() - (model.countLeaves() <= 4 ? 0 : 1);
	leafHeight = (getHeight() - headerHeight) / leavesToFit;
	
	// Background stripse
	for (int r = 0; r <= model.getRoot().getRound(); r++) {
	    int lRound = r*roundWidth-roundWidth/2, rRound = lRound + roundWidth;
	    if (r % 2 == 1) {
		g.setColor(new Color(220, 220, 220));
		g.fillRect(lRound, 0, roundWidth, getHeight());
	    }
	    if (r > 0) {
		g.setColor(BLACK);
		drawCenteredString("round " + r, (rRound+lRound)/2, headerHeight/2);
	    }
	}
	
	// Draw tree
	top = headerHeight;
	right = getWidth() - roundWidth / 4;
	win = false;
	
	model.getRoot().accept(this);
	
    }
    
    private void drawCenteredString(String str, int cx, int cy) {
        g.setColor(BLACK);
        Rectangle rect = strRect(str);
        g.drawString(str, cx-rect.width/2, cy+rect.height/2);
    }
    
    private Rectangle strRect(String str) {
        FontMetrics fm = g.getFontMetrics();
        return fm.getStringBounds(str, g).getBounds();
    }
    
    private void drawPlayerBox(TournamentNode node, int cy, String text) {
        
	int y = cy - boxHeight / 2;
	
	rootRect = new Rectangle(right - boxWidth, y, boxWidth, boxHeight);
	g.setColor(win ? WINCOL : DEFCOL);
	
	g.fill(rootRect);
	
	if (faded)
	    g.setStroke(new BasicStroke(1,BasicStroke.CAP_SQUARE, 0, 1, new float[] {2,2}, 0));
	
	g.setColor(BLACK);
        g.draw(rootRect);
	
	g.setColor(text == null ? BLACK : LIGHT_GRAY);
	if (text == null) {
	    Player p = node.getSucceeder();
	    text = p == null ? "" : p.toString();
	}
	
	if (!faded) {
	    FontMetrics fm = g.getFontMetrics();
	    g.drawString(text, (int) rootRect.getX()+2, (int) rootRect.getMaxY()-fm.getDescent());
	}
	
        g.setStroke(new BasicStroke());

    }
    
    private int getRootY() {
        return (int) rootRect.getCenterY();
    }
    
    private Rectangle getHoverRect(Point p) {
	for (Rectangle r : clickables.keySet())
	    if (r.contains(p))
		return r;
	return null;
    }
    
    
    public void visit(InitialNode initialNode) {
        drawPlayerBox(initialNode, top + leafHeight / 2, null);
        bottom = top + leafHeight;
    }
    
    public void visit(WinnerNode winnerNode) {
        drawWinnerNode(winnerNode, false);
    }
    
    public void visit(LoserNode loserNode) {
        
        String s = loserNode.complementNode.match.status == Status.NOT_PLAYED ?
                "L"+loserNode.complementNode.match.id : null;
        
        drawPlayerBox(loserNode, top + leafHeight / 2, s);
        bottom = top + leafHeight;
    }
    
    public void visit(SingleNode singleNode) {
        right -= roundWidth;
        singleNode.pred.accept(this);
        right += roundWidth;
        drawPlayerBox(singleNode, getRootY(), null);
        drawLines(getRootY(), getRootY());
    }
    
    public void visit(Final2Node final2Node) {
        drawWinnerNode(final2Node, true);
    }
    
    private void drawWinnerNode(WinnerNode winnerNode, boolean isFinal2) {
        
        boolean isPlayable = winnerNode.pred1.getSucceeder() != null &&
                             winnerNode.pred2.getSucceeder() != null;
        
        int oldTop = top;
        boolean oldWin = win, oldFaded = faded;
        
        right -= roundWidth;
        win = winnerNode.match.status == P1WON;
        winnerNode.pred1.accept(this);
        int rootYupper = getRootY();
        if (isPlayable)
            clickables.put(rootRect, new SetMatchStatus(winnerNode.match, P1WON));
        
        top = isFinal2 ? getRootY() + leafHeight : bottom;
        win = winnerNode.match.status == P2WON;
        faded = !winnerNode.isNeccessary();
        winnerNode.pred2.accept(this);
        int rootYlower = getRootY();
        if (isPlayable)
            clickables.put(rootRect, new SetMatchStatus(winnerNode.match, P2WON));
        
        // Restore input
        top = oldTop;
        right += roundWidth;
        win = oldWin;
        
        drawPlayerBox(winnerNode, (rootYupper + rootYlower) / 2, null);
        String str = winnerNode.inWb ? winnerNode.match.toString() : "";
        drawLines(rootYupper, rootYlower, str);
        faded = oldFaded;
    }
    
    private void drawLines(int rootYupper, int rootYlower) {
        drawLines(rootYupper, rootYlower, "");
    }
    
    private void drawLines(int rootYupper, int rootYlower, String str) {
        int l = right - roundWidth;
        int r = right - boxWidth;
        int cx = (r + l) / 2;
        
        if (faded)
            g.setStroke(new BasicStroke(1,BasicStroke.CAP_SQUARE, 0, 1, new float[] {2,2}, 0));
        
        g.setColor(BLACK);
        g.drawLine(l, rootYupper, cx, rootYupper);
        g.drawLine(l, rootYlower, cx, rootYlower);
        g.drawLine(cx, rootYupper, cx, rootYlower);
        g.drawLine(cx, getRootY(), r, getRootY());
        
        g.setStroke(new BasicStroke());
        
        FontMetrics fm = g.getFontMetrics();
        Rectangle rect = fm.getStringBounds(str, g).getBounds();
        g.drawString(str, cx-rect.width, getRootY()+rect.height/2-fm.getDescent());
    }
    
    
    class SetMatchStatus {
        Match match;
        Status status;
        
        public SetMatchStatus(Match match, Status status) {
            this.match = match;
            this.status = status;
        }

        public void set() {
            match.status = status;
        }
    }
}
