package net.aioobe.tournaments;


public class LoserNode extends TournamentNode {
    
    WinnerNode complementNode;
    
    public LoserNode(WinnerNode complementNode) {
	this.complementNode = complementNode;
    }
    
    public Player getSucceeder() {
	return complementNode.getLoser();
    }

    public void accept(TournamentVisitor visitor) {
        visitor.visit(this);
    }
    
    public int getRound() {
        return complementNode.getRound();
    }
}
