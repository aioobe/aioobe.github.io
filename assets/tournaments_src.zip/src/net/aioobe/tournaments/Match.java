package net.aioobe.tournaments;


public class Match {
    
    
    static int count = 0;
    int id = ++count;
    public String toString() {
        return ""+id;
    }
    public Match() {
//        System.out.println(this);
    }
    
    
    
    enum Status {
        NOT_PLAYED, P1WON, P2WON;
        
        public static Status parseStatus(String str) {
            for (Status s : values())
                if (s.toString().equals(str))
                    return s;
            System.out.println("Could not parse " + str);
            System.exit(-1);
            return null;
        }
    };
    
    Status status = Status.NOT_PLAYED;
    
    Status getStatus() {
	return status;
    }
    
    public boolean isPlayed() {
	return status != Status.NOT_PLAYED;
    }

}
